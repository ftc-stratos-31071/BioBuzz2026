package org.firstinspires.ftc.teamcode.shooter;

import com.seattlesolvers.solverslib.command.CommandBase;

public class ShootCommand extends CommandBase {
    private final ShooterSubsystem shooter;

    public ShootCommand(ShooterSubsystem s) {
        shooter = s;
        addRequirements(s);
    }

    @Override
    public void initialize() {
        shooter.toggleMotor();
    }

    @Override
    public boolean isFinished() {
        return true; // Ends immediately after toggling
    }
}