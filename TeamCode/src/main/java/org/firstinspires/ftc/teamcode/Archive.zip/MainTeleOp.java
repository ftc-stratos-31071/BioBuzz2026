package org.firstinspires.ftc.teamcode;

import com.seattlesolvers.solverslib.command.CommandOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.seattlesolvers.solverslib.command.button.GamepadButton;
import com.seattlesolvers.solverslib.gamepad.GamepadEx;
import com.seattlesolvers.solverslib.gamepad.GamepadKeys;

@TeleOp(name = "Main TeleOp", group = "TeleOp")
public class MainTeleOp extends CommandOpMode {

    private ShooterSubsystem shooter;
    private GamepadEx gamepad;

    @Override
    public void initialize() {
        gamepad = new GamepadEx(gamepad1);
        // 1. Initialize your hardware and subsystems using hardwareMap
        shooter = new ShooterSubsystem(hardwareMap, "hood", "shooter");

//        shooter.setMotorSpeed(1000);

        GamepadButton toggleReader = new GamepadButton(gamepad, GamepadKeys.Button.Y);

        toggleReader.whenPressed(new ShootCommand(shooter));
//
//        GamepadButton x = new GamepadButton(gamepad, GamepadKeys.Button.X);
//
//        x.whenPressed(new StopMotorCommand(shooter));


//        while (true) {
//            gamepad.readButtons();
//            shooter.setState(toggleReader.getState());
////            if (gamepad.wasJustReleased(GamepadKeys.Button.Y)) {
////                shooter.toggleMotor();
////            }
//            if (gamepad.wasJustReleased(GamepadKeys.Button.B)) {
//                shooter.increaseRPM();
//            }
//            if (gamepad.wasJustReleased(GamepadKeys.Button.X)) {
//                shooter.decreaseRPM();
//            }
//            if (gamepad.wasJustReleased(GamepadKeys.Button.DPAD_RIGHT)) {
//                shooter.increaseHoodAngle();
//            }
//            if (gamepad.wasJustReleased(GamepadKeys.Button.DPAD_LEFT)) {
//                shooter.decreaseHoodAngle();
//            }
//
//        }

//        // 2. Set default commands or register button bindings if using GamepadEx
//        intakeSubsystem.setDefaultCommand(
//                new RunCommand(() -> intakeSubsystem.runIntake(0.5), intakeSubsystem)
//        );
//
//        // 3. Telemetry or additional setup can go here
//        telemetry.addData("Status", "Command OpMode Initialized");
//        telemetry.update();
    }
}