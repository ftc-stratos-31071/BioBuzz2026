package org.firstinspires.ftc.teamcode;

import com.acmerobotics.dashboard.config.Config;
import com.seattlesolvers.solverslib.command.SubsystemBase;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.seattlesolvers.solverslib.hardware.motors.Motor;
import com.seattlesolvers.solverslib.hardware.motors.MotorEx;
import com.seattlesolvers.solverslib.hardware.servos.ServoEx;

@Config
public class ShooterSubsystem extends SubsystemBase {
    private final ServoEx servo;
    public final MotorEx motor;
    public static double RPM = 500;
    public static boolean motorRunning = true;
    public double servoAngle = 0;
    public ShooterSubsystem(final HardwareMap hMap, final String servoName, final String motorName) {
        servo = new ServoEx(hMap, servoName, 180);

        motor = new MotorEx(hMap, motorName);
        motor.setRunMode(MotorEx.RunMode.VelocityControl);
        motor.setZeroPowerBehavior(MotorEx.ZeroPowerBehavior.FLOAT);


        motor.resetEncoder();
//        motor.setVelocity((RPM*28)/60.0);
    }

    @Override
    public void periodic() {
        // called once per scheduler loop, use for checking things constantly
    }

    public void toggleMotor() {
        // motor measures in ticks per second, not rpm - the motor has 28 ticks per revolution
        motorRunning = !motorRunning;
        if (motorRunning) motor.setVelocity((RPM * 28) / 60.0);
        else motor.setVelocity(0);
//        motorRunning = !motorRunning;
    }

//    public void setMotorSpeed(double rpm) {
//        if (rpm == 0) {
//            motor.setVelocity(0);
//        } else {
//            motor.setVelocity(RPM);
//        }
//    }


    public void increaseRPM() {
        if (motorRunning) {
            RPM += 100;
            motor.setVelocity((RPM * 28) / 60.0); // rpm --> tps : multiply revolutions by 28 to get ticks, divide by 60 to get per second from per minute
        }
    }

    public void decreaseRPM() {
        if (motorRunning) {
            RPM -= 100;
            motor.setVelocity((RPM * 28) / 60.0); // rpm --> tps : multiply revolutions by 28 to get ticks, divide by 60 to get per second from per minute
        }
    }

    public void increaseHoodAngle() {
        // CREATE CONSTRAINTS FOR SERVO
        servoAngle += 10;
        servo.set(servoAngle);
    }

    public void decreaseHoodAngle() {
        servoAngle -= 10;
        servo.set(servoAngle);
    }
}